#!/bin/bash

echo "📦 Instalando Atualizador do DBeaver..."

# Criar script de atualização
cp ./atualiza_dbeaver.sh ~/atualiza_dbeaver.sh
chmod +x ~/atualiza_dbeaver.sh

# Baixar ícone
mkdir -p ~/.local/share/icons
wget -q -O ~/.local/share/icons/dbeaver.png https://raw.githubusercontent.com/dbeaver/dbeaver/master/plugins/org.jkiss.dbeaver.ui/icons/dbeaver.png

# Criar atalho .desktop
mkdir -p ~/.local/share/applications
cp ./AtualizaDBeaver.desktop ~/.local/share/applications/AtualizaDBeaver.desktop

# Atualizar menu
update-desktop-database ~/.local/share/applications

echo "✅ Instalador finalizado. Verifique o menu do sistema."
notify-send "Atualizador DBeaver instalado com sucesso!" "Pronto para usar no menu do sistema 🎉" -i /home/$USER/.local/share/icons/dbeaver.png
