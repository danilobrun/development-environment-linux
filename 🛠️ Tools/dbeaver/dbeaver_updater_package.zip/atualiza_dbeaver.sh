#!/bin/bash

notificar() {
    notify-send "Atualização DBeaver" "$1" -i /home/$USER/.local/share/icons/dbeaver.png -u normal
}

echo "🚀 Iniciando verificação de atualização do DBeaver..."
notificar "Verificando atualizações do DBeaver..."

sudo apt update

DISPONIVEL=$(apt list --upgradable 2>/dev/null | grep dbeaver-ce)

if [ -z "$DISPONIVEL" ]; then
    echo "✅ DBeaver já está na versão mais recente."
    notificar "✅ DBeaver já está na última versão."
else
    echo "🔄 Atualização encontrada! Atualizando DBeaver..."
    notificar "Atualizando DBeaver para a versão mais recente..."
    sudo apt install --only-upgrade dbeaver-ce -y
    echo "✅ DBeaver atualizado com sucesso!"
    notificar "✅ Atualização do DBeaver concluída com sucesso!"
fi

echo "🎯 Script finalizado."
